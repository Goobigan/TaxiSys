﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaxiSys
{
    internal class DBConnect
    {
        public const String oraDB = "Data Source = studentoracle:1521/orcl; User ID = t00242943; Password = jeb#Tfufkj4e;";
    }
}
